package com.restaurant.model;

import com.restaurant.enums.Role;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Waiter extends Staff {
    private final List<RestaurantTable> assignedTables = new ArrayList<>();

    public Waiter(String username, String password, LocalDate dateOfBirth, String workingHours) {
        super(username, password, dateOfBirth, Role.WAITER, workingHours);
    }

    public void assignTable(RestaurantTable table) {
        if (!assignedTables.contains(table)) {
            assignedTables.add(table);
        }
    }

    public List<RestaurantTable> getAssignedTables() {
        return Collections.unmodifiableList(assignedTables);
    }

    @Override
    public String getDashboardTitle() {
        return "Waiter Dashboard";
    }
}
