package com.restaurant.enums;

public enum PaymentStatus {
    UNPAID,
    PAID
}
