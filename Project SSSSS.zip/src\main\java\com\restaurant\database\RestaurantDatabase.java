package com.restaurant.database;

import com.restaurant.enums.TableLocation;
import com.restaurant.exception.RestaurantException;
import com.restaurant.model.*;
import com.restaurant.util.ValidationUtil;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public final class RestaurantDatabase {
    public static final ArrayList<Customer> customers = new ArrayList<>();
    public static final ArrayList<Staff> staff = new ArrayList<>();
    public static final ArrayList<RestaurantTable> tables = new ArrayList<>();
    public static final ArrayList<Reservation> reservations = new ArrayList<>();
    public static final ArrayList<Order> orders = new ArrayList<>();
    public static final ArrayList<Invoice> invoices = new ArrayList<>();
    public static final ArrayList<MenuCategory> menuCategories = new ArrayList<>();
    public static final ArrayList<MenuItem> menuItems = new ArrayList<>();

    private static int nextReservationId = 1;
    private static int nextOrderId = 100;
    private static int nextInvoiceId = 500;
    private static int nextCategoryId = 1;
    private static int nextMenuItemId = 1;
    private static boolean initialized;

    private RestaurantDatabase() {
    }

    public static synchronized void initializeSampleData() {
        if (initialized) {
            return;
        }
        customers.add(new Customer("customer1", "password123", LocalDate.of(2002, 5, 12), 1000, "01012345678", "Vegetarian, window seat"));
        customers.add(new Customer("customer2", "password123", LocalDate.of(2001, 9, 3), 700, "01098765432", "Nut allergy"));

        staff.add(new Admin("admin", "admin123", LocalDate.of(1990, 1, 10), "10:00-18:00"));
        Waiter waiter = new Waiter("waiter", "waiter123", LocalDate.of(1998, 4, 22), "15:00-23:00");
        Waiter waiter2 = new Waiter("waiter2", "waiter123", LocalDate.of(1997, 8, 6), "10:00-18:00");
        staff.add(waiter);
        staff.add(waiter2);

        for (int i = 1; i <= 8; i++) {
            TableLocation location = i <= 3 ? TableLocation.INDOOR : i <= 6 ? TableLocation.OUTDOOR : TableLocation.VIP;
            int capacity = i == 1 ? 2 : i <= 4 ? 4 : i <= 6 ? 6 : 8;
            RestaurantTable table = new RestaurantTable(i, capacity, location);
            tables.add(table);
            if (i % 2 == 0) {
                waiter.assignTable(table);
            } else {
                waiter2.assignTable(table);
            }
        }

        MenuCategory appetizers = addCategoryInternal("Appetizers", "Small dishes to start the meal");
        MenuCategory main = addCategoryInternal("Main Course", "Main restaurant dishes");
        MenuCategory beverages = addCategoryInternal("Beverages", "Cold and hot drinks");
        MenuCategory desserts = addCategoryInternal("Desserts", "Sweet dishes");

        addMenuItemInternal("Bruschetta", 85, "Toasted bread with tomato and basil", appetizers, true);
        addMenuItemInternal("Chicken Wings", 120, "Spicy glazed wings", appetizers, true);
        addMenuItemInternal("Grilled Salmon", 280, "Salmon with lemon butter", main, true);
        addMenuItemInternal("Beef Burger", 190, "Burger with fries", main, true);
        addMenuItemInternal("Pasta Alfredo", 165, "Creamy pasta with mushrooms", main, true);
        addMenuItemInternal("Fresh Orange Juice", 60, "Freshly squeezed juice", beverages, true);
        addMenuItemInternal("Iced Coffee", 70, "Cold coffee with milk", beverages, true);
        addMenuItemInternal("Chocolate Cake", 95, "Rich chocolate slice", desserts, true);
        addMenuItemInternal("Cheesecake", 105, "Classic cheesecake", desserts, false);

        initialized = true;
    }

    public static synchronized void resetForTests() {
        customers.clear();
        staff.clear();
        tables.clear();
        reservations.clear();
        orders.clear();
        invoices.clear();
        menuCategories.clear();
        menuItems.clear();
        nextReservationId = 1;
        nextOrderId = 100;
        nextInvoiceId = 500;
        nextCategoryId = 1;
        nextMenuItemId = 1;
        initialized = false;
        initializeSampleData();
    }

    public static synchronized Customer addCustomer(Customer customer) {
        ValidationUtil.requireUsername(customer.getUsername());
        ValidationUtil.requirePassword(customer.getPassword());
        ValidationUtil.requirePhone(customer.getPhoneNumber());
        ValidationUtil.requireDateOfBirth(customer.getDateOfBirth());
        if (findCustomer(customer.getUsername()) != null || findStaff(customer.getUsername()) != null) {
            throw new RestaurantException("Username already exists.");
        }
        customers.add(customer);
        return customer;
    }

    public static synchronized Customer findCustomer(String username) {
        for (Customer customer : customers) {
            if (customer.getUsername().equalsIgnoreCase(username)) {
                return customer;
            }
        }
        return null;
    }

    public static synchronized Staff findStaff(String username) {
        for (Staff employee : staff) {
            if (employee.getUsername().equalsIgnoreCase(username)) {
                return employee;
            }
        }
        return null;
    }

    public static synchronized RestaurantTable findTable(int tableNumber) {
        for (RestaurantTable table : tables) {
            if (table.getTableNumber() == tableNumber) {
                return table;
            }
        }
        return null;
    }

    public static synchronized Order findOrder(int id) {
        for (Order order : orders) {
            if (order.getId() == id) {
                return order;
            }
        }
        return null;
    }

    public static synchronized MenuItem findMenuItem(int id) {
        for (MenuItem item : menuItems) {
            if (item.getId() == id) {
                return item;
            }
        }
        return null;
    }

    public static synchronized MenuCategory findCategory(int id) {
        for (MenuCategory category : menuCategories) {
            if (category.getId() == id) {
                return category;
            }
        }
        return null;
    }

    public static synchronized int nextReservationId() {
        return nextReservationId++;
    }

    public static synchronized int nextOrderId() {
        return nextOrderId++;
    }

    public static synchronized int nextInvoiceId() {
        return nextInvoiceId++;
    }

    public static synchronized int nextCategoryId() {
        return nextCategoryId++;
    }

    public static synchronized int nextMenuItemId() {
        return nextMenuItemId++;
    }

    public static synchronized List<RestaurantTable> tableSnapshot() {
        return new ArrayList<>(tables);
    }

    public static synchronized List<MenuItem> menuItemSnapshot() {
        return new ArrayList<>(menuItems);
    }

    public static synchronized List<Order> orderSnapshot() {
        return new ArrayList<>(orders);
    }

    public static synchronized List<Reservation> reservationSnapshot() {
        return new ArrayList<>(reservations);
    }

    private static MenuCategory addCategoryInternal(String name, String description) {
        MenuCategory category = new MenuCategory(nextCategoryId++, name, description);
        menuCategories.add(category);
        return category;
    }

    private static MenuItem addMenuItemInternal(String name, double price, String description, MenuCategory category, boolean available) {
        MenuItem item = new MenuItem(nextMenuItemId++, name, price, description, category, available);
        menuItems.add(item);
        return item;
    }

    public static synchronized boolean tableHasReservationOverlap(RestaurantTable table, LocalDateTime dateTime, int lengthMinutes) {
        for (Reservation reservation : reservations) {
            if (!reservation.isCancelled() && reservation.getTable() == table && reservation.overlaps(dateTime, lengthMinutes)) {
                return true;
            }
        }
        return false;
    }
}
