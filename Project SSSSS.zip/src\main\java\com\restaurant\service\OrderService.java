package com.restaurant.service;

import com.restaurant.database.RestaurantDatabase;
import com.restaurant.enums.OrderStatus;
import com.restaurant.exception.RestaurantException;
import com.restaurant.model.*;

public class OrderService {
    public synchronized Order createOrder(Customer customer, RestaurantTable table) {
        if (customer == null || table == null) {
            throw new RestaurantException("Customer and table are required.");
        }
        Order order = new Order(RestaurantDatabase.nextOrderId(), customer, table);
        synchronized (RestaurantDatabase.class) {
            RestaurantDatabase.orders.add(order);
            customer.addOrder(order);
            table.occupy(order);
        }
        return order;
    }

    public synchronized void addItem(Order order, MenuItem item, int quantity, String notes) {
        if (order == null) {
            throw new RestaurantException("Order is required.");
        }
        order.addItem(item, quantity, notes);
    }

    public synchronized void updateStatus(Order order, OrderStatus status) {
        if (order == null) {
            throw new RestaurantException("Order is required.");
        }
        order.updateStatus(status);
    }

    public synchronized Invoice checkout(Order order) {
        if (order == null || order.getItems().isEmpty()) {
            throw new RestaurantException("Cannot checkout an empty order.");
        }
        for (Invoice invoice : RestaurantDatabase.invoices) {
            if (invoice.getOrder() == order) {
                return invoice;
            }
        }
        Invoice invoice = new Invoice(RestaurantDatabase.nextInvoiceId(), order);
        RestaurantDatabase.invoices.add(invoice);
        return invoice;
    }
}
