package com.restaurant.service;

import com.restaurant.database.RestaurantDatabase;
import com.restaurant.exception.RestaurantException;
import com.restaurant.model.Customer;
import com.restaurant.model.Reservation;
import com.restaurant.model.RestaurantTable;
import com.restaurant.util.RestaurantConstants;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ReservationService {
    public synchronized Reservation createReservation(Customer customer, RestaurantTable table, LocalDateTime dateTime, int partySize) {
        synchronized (RestaurantDatabase.class) {
            validateReservation(customer, table, dateTime, partySize);
            Reservation reservation = new Reservation(RestaurantDatabase.nextReservationId(), customer, table, dateTime, partySize);
            RestaurantDatabase.reservations.add(reservation);
            customer.addReservation(reservation);
            table.reserve(reservation);
            return reservation;
        }
    }

    public synchronized void cancelReservation(Reservation reservation) {
        if (reservation == null || reservation.isCancelled()) {
            throw new RestaurantException("Reservation is not active.");
        }
        reservation.cancel();
        reservation.getCustomer().removeReservation(reservation);
    }

    public List<RestaurantTable> findAvailableTables(LocalDateTime dateTime, int partySize) {
        List<RestaurantTable> result = new ArrayList<>();
        synchronized (RestaurantDatabase.class) {
            for (RestaurantTable table : RestaurantDatabase.tables) {
                if (partySize <= table.getCapacity()
                        && !RestaurantDatabase.tableHasReservationOverlap(table, dateTime, RestaurantConstants.RESERVATION_LENGTH_MINUTES)) {
                    result.add(table);
                }
            }
        }
        return result;
    }

    private void validateReservation(Customer customer, RestaurantTable table, LocalDateTime dateTime, int partySize) {
        if (customer == null || table == null || dateTime == null) {
            throw new RestaurantException("Customer, table, and date/time are required.");
        }
        if (dateTime.isBefore(LocalDateTime.now())) {
            throw new RestaurantException("Reservation date/time must be in the future.");
        }
        if (dateTime.toLocalTime().isBefore(RestaurantConstants.OPENING_TIME)
                || dateTime.toLocalTime().plusMinutes(RestaurantConstants.RESERVATION_LENGTH_MINUTES).isAfter(RestaurantConstants.CLOSING_TIME)) {
            throw new RestaurantException("Reservation must be within restaurant operating hours.");
        }
        if (partySize <= 0 || partySize > table.getCapacity()) {
            throw new RestaurantException("Party size exceeds table capacity.");
        }
        synchronized (RestaurantDatabase.class) {
            if (RestaurantDatabase.tableHasReservationOverlap(table, dateTime, RestaurantConstants.RESERVATION_LENGTH_MINUTES)) {
                throw new RestaurantException("This table is already reserved for the selected time.");
            }
        }
    }
}
