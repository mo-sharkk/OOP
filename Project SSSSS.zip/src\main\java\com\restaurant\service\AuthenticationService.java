package com.restaurant.service;

import com.restaurant.database.RestaurantDatabase;
import com.restaurant.exception.RestaurantException;
import com.restaurant.model.Customer;
import com.restaurant.model.Staff;
import com.restaurant.util.ValidationUtil;

import java.time.LocalDate;

public class AuthenticationService {
    public AuthResult login(String username, String password) {
        Customer customer = RestaurantDatabase.findCustomer(username);
        if (customer != null && customer.getPassword().equals(password)) {
            return new AuthResult(customer, null);
        }
        Staff staff = RestaurantDatabase.findStaff(username);
        if (staff != null && staff.getPassword().equals(password)) {
            return new AuthResult(null, staff);
        }
        throw new RestaurantException("Invalid username or password.");
    }

    public Customer registerCustomer(String username, String password, String confirmPassword, LocalDate dob, String phone, String preferences) {
        if (!password.equals(confirmPassword)) {
            throw new RestaurantException("Password and confirm password must match.");
        }
        ValidationUtil.requireUsername(username);
        ValidationUtil.requirePassword(password);
        ValidationUtil.requireDateOfBirth(dob);
        ValidationUtil.requirePhone(phone);
        Customer customer = new Customer(username, password, dob, 500, phone, preferences);
        return RestaurantDatabase.addCustomer(customer);
    }
}
