# Test Cases

## Valid Cases

- Customer logs in with `customer1 / password123`.
- Admin logs in with `admin / admin123`.
- Waiter logs in with `waiter / waiter123`.
- New customer registers with a unique username, strong password, valid date of birth, and valid phone number.
- Customer reserves an available table during operating hours.
- Party size 4 is accepted for a table with capacity 4.
- Customer cancels an active reservation.
- Available menu items can be added to an order.
- Waiter changes order status from `PLACED` to `PREPARING` and then `SERVED`.
- Invoice calculates subtotal, tax, service charge, and final total.
- Customer pays using `CASH`, `CARD`, or `ONLINE`.
- Server broadcasts `ORDER_STATUS|101|PREPARING` to connected clients.

## Invalid Cases

- Login with a wrong password is rejected.
- Duplicate username registration is rejected.
- Weak password without digits is rejected.
- Invalid phone number is rejected.
- Reservation in the past is rejected.
- Reservation outside operating hours is rejected.
- Double booking the same table in an overlapping slot is rejected.
- Party size larger than table capacity is rejected.
- Unavailable menu item cannot be ordered.
- Quantity 0 or negative is rejected.
- Paid order cannot move backward to an earlier status.
- Malformed socket messages receive an error response.
