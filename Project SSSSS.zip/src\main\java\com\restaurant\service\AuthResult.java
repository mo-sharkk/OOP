package com.restaurant.service;

import com.restaurant.model.Customer;
import com.restaurant.model.Staff;

public class AuthResult {
    private final Customer customer;
    private final Staff staff;

    public AuthResult(Customer customer, Staff staff) {
        this.customer = customer;
        this.staff = staff;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Staff getStaff() {
        return staff;
    }

    public boolean isCustomer() {
        return customer != null;
    }
}
