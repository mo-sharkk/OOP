package com.restaurant.controller;

import com.restaurant.Main;
import com.restaurant.enums.Role;
import com.restaurant.exception.RestaurantException;
import com.restaurant.model.Staff;
import com.restaurant.service.AuthResult;
import com.restaurant.service.AuthenticationService;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.IOException;

public class LoginController {
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private TextField registerUsernameField;
    @FXML private PasswordField registerPasswordField;
    @FXML private PasswordField confirmPasswordField;
    @FXML private DatePicker dobPicker;
    @FXML private TextField phoneField;
    @FXML private TextArea preferencesArea;
    @FXML private Label statusLabel;

    private final AuthenticationService authenticationService = new AuthenticationService();

    @FXML
    private void login() {
        try {
            AuthResult result = authenticationService.login(usernameField.getText(), passwordField.getText());
            if (result.isCustomer()) {
                AppSession.setCurrentCustomer(result.getCustomer());
                Main.showScreen("/fxml/CustomerDashboard.fxml");
            } else {
                Staff staff = result.getStaff();
                AppSession.setCurrentStaff(staff);
                Main.showScreen(staff.getRole() == Role.ADMIN ? "/fxml/AdminDashboard.fxml" : "/fxml/WaiterDashboard.fxml");
            }
        } catch (RestaurantException | IOException ex) {
            statusLabel.setText(ex.getMessage());
        }
    }

    @FXML
    private void register() {
        try {
            authenticationService.registerCustomer(
                    registerUsernameField.getText(),
                    registerPasswordField.getText(),
                    confirmPasswordField.getText(),
                    dobPicker.getValue(),
                    phoneField.getText(),
                    preferencesArea.getText());
            statusLabel.setText("Registration successful. You can now login.");
            registerUsernameField.clear();
            registerPasswordField.clear();
            confirmPasswordField.clear();
            phoneField.clear();
            preferencesArea.clear();
        } catch (RestaurantException ex) {
            statusLabel.setText(ex.getMessage());
        }
    }
}
