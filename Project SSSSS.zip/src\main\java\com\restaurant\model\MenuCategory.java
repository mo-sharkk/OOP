package com.restaurant.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MenuCategory {
    private int id;
    private String name;
    private String description;
    private final List<MenuItem> items = new ArrayList<>();

    public MenuCategory(int id, String name, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<MenuItem> getItems() {
        return Collections.unmodifiableList(items);
    }

    public void addItem(MenuItem item) {
        if (!items.contains(item)) {
            items.add(item);
        }
    }

    public void removeItem(MenuItem item) {
        items.remove(item);
    }

    @Override
    public String toString() {
        return name;
    }
}
