package com.restaurant.enums;

public enum PaymentMethod {
    CASH,
    CARD,
    ONLINE
}
