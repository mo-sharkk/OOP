package com.restaurant.controller;

import com.restaurant.Main;
import com.restaurant.database.RestaurantDatabase;
import com.restaurant.enums.OrderStatus;
import com.restaurant.enums.PaymentMethod;
import com.restaurant.enums.TableLocation;
import com.restaurant.exception.RestaurantException;
import com.restaurant.model.Customer;
import com.restaurant.model.Invoice;
import com.restaurant.model.MenuItem;
import com.restaurant.model.Order;
import com.restaurant.model.Reservation;
import com.restaurant.model.RestaurantTable;
import com.restaurant.network.NetworkMessageListener;
import com.restaurant.service.OrderService;
import com.restaurant.service.PaymentService;
import com.restaurant.service.ReservationService;
import com.restaurant.util.DisplayFormat;
import com.restaurant.util.RestaurantConstants;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class CustomerDashboardController implements NetworkMessageListener {
    @FXML private Label welcomeLabel;
    @FXML private Label balanceLabel;
    @FXML private Label loyaltyLabel;
    @FXML private Label networkLabel;
    @FXML private ListView<Reservation> reservationList;
    @FXML private ListView<Order> orderList;
    @FXML private ListView<RestaurantTable> tableList;
    @FXML private ComboBox<TableLocation> locationFilter;
    @FXML private TextField capacityFilter;
    @FXML private DatePicker reservationDatePicker;
    @FXML private TextField reservationTimeField;
    @FXML private TextField partySizeField;
    @FXML private ListView<MenuItem> menuList;
    @FXML private TextField quantityField;
    @FXML private TextField notesField;
    @FXML private Label orderTotalLabel;
    @FXML private ComboBox<PaymentMethod> paymentMethodCombo;
    @FXML private Label invoiceLabel;

    private final ReservationService reservationService = new ReservationService();
    private final OrderService orderService = new OrderService();
    private final PaymentService paymentService = new PaymentService();
    private final ScheduledExecutorService refreshExecutor = Executors.newSingleThreadScheduledExecutor(runnable -> {
        Thread thread = new Thread(runnable, "table-refresh");
        thread.setDaemon(true);
        return thread;
    });
    private Customer customer;
    private Order activeOrder;

    @FXML
    private void initialize() {
        customer = AppSession.getCurrentCustomer();
        welcomeLabel.setText("Welcome, " + customer.getUsername());
        locationFilter.setItems(FXCollections.observableArrayList(TableLocation.values()));
        paymentMethodCombo.setItems(FXCollections.observableArrayList(PaymentMethod.values()));
        paymentMethodCombo.getSelectionModel().select(PaymentMethod.CASH);
        reservationDatePicker.setValue(LocalDate.now().plusDays(1));
        reservationTimeField.setText("19:00");
        partySizeField.setText("2");
        quantityField.setText("1");
        Main.getClient().addListener(this);
        loadMenuInBackground();
        refreshAll();
        refreshExecutor.scheduleAtFixedRate(() -> Platform.runLater(this::refreshTables), 0,
                RestaurantConstants.TABLE_REFRESH_SECONDS, TimeUnit.SECONDS);
    }

    @FXML
    private void refreshAll() {
        balanceLabel.setText("Balance: " + DisplayFormat.money(customer.getBalance()) + " EGP");
        loyaltyLabel.setText("Loyalty points: " + DisplayFormat.number(customer.getLoyaltyPoints()));
        reservationList.setItems(FXCollections.observableArrayList(customer.getReservations()));
        orderList.setItems(FXCollections.observableArrayList(customer.getOrders()));
        refreshTables();
        updateOrderTotal();
    }

    @FXML
    private void refreshTables() {
        List<RestaurantTable> tables = RestaurantDatabase.tableSnapshot();
        List<RestaurantTable> filtered = new ArrayList<>();
        int capacity = parseIntOrDefault(capacityFilter.getText(), 0);
        for (RestaurantTable table : tables) {
            if (locationFilter.getValue() != null && table.getLocation() != locationFilter.getValue()) {
                continue;
            }
            if (capacity > 0 && table.getCapacity() < capacity) {
                continue;
            }
            filtered.add(table);
        }
        tableList.setItems(FXCollections.observableArrayList(filtered));
        if (!filtered.isEmpty() && tableList.getSelectionModel().getSelectedItem() == null) {
            tableList.getSelectionModel().selectFirst();
        }
    }

    @FXML
    private void createReservation() {
        try {
            RestaurantTable table = tableList.getSelectionModel().getSelectedItem();
            LocalDate date = reservationDatePicker.getValue();
            if (table == null) {
                throw new RestaurantException("Select a table first.");
            }
            if (date == null) {
                throw new RestaurantException("Select a reservation date.");
            }
            LocalTime time = parseReservationTime();
            int partySize = parsePartySize();
            Reservation reservation = reservationService.createReservation(customer, table, LocalDateTime.of(date, time), partySize);
            AlertUtil.info("Reservation confirmed: " + reservation);
            refreshAll();
        } catch (Exception ex) {
            AlertUtil.error(ex.getMessage());
        }
    }

    @FXML
    private void cancelReservation() {
        try {
            reservationService.cancelReservation(reservationList.getSelectionModel().getSelectedItem());
            AlertUtil.info("Reservation cancelled.");
            refreshAll();
        } catch (RestaurantException ex) {
            AlertUtil.error(ex.getMessage());
        }
    }

    @FXML
    private void startOrder() {
        try {
            RestaurantTable table = tableList.getSelectionModel().getSelectedItem();
            activeOrder = orderService.createOrder(customer, table);
            AlertUtil.info("Order " + activeOrder.getId() + " started.");
            refreshAll();
        } catch (RestaurantException ex) {
            AlertUtil.error(ex.getMessage());
        }
    }

    @FXML
    private void addMenuItem() {
        try {
            if (activeOrder == null) {
                startOrder();
            }
            MenuItem item = menuList.getSelectionModel().getSelectedItem();
            orderService.addItem(activeOrder, item, Integer.parseInt(quantityField.getText()), notesField.getText());
            AlertUtil.info("Item added to order.");
            refreshAll();
        } catch (Exception ex) {
            AlertUtil.error(ex.getMessage());
        }
    }

    @FXML
    private void checkout() {
        try {
            Order selected = orderList.getSelectionModel().getSelectedItem();
            if (selected == null) {
                selected = activeOrder;
            }
            Invoice invoice = orderService.checkout(selected);
            invoiceLabel.setText("Subtotal " + DisplayFormat.money(invoice.getSubtotal())
                    + " | Tax " + DisplayFormat.money(invoice.getTax())
                    + " | Service " + DisplayFormat.money(invoice.getServiceCharge())
                    + " | Total " + DisplayFormat.money(invoice.getFinalTotal()));
            paymentService.pay(invoice, paymentMethodCombo.getValue());
            Main.getClient().sendOrderStatus(invoice.getOrder().getId(), invoice.getOrder().getStatus().name());
            AlertUtil.info("Payment completed successfully.");
            refreshAll();
        } catch (Exception ex) {
            AlertUtil.error(ex.getMessage());
        }
    }

    @FXML
    private void logout() throws IOException {
        refreshExecutor.shutdownNow();
        Main.getClient().removeListener(this);
        AppSession.clear();
        Main.showScreen("/fxml/Login.fxml");
    }

    private void loadMenuInBackground() {
        menuList.setPlaceholder(new Label("Loading menu..."));
        Thread loader = new Thread(() -> {
            List<MenuItem> items = RestaurantDatabase.menuItemSnapshot();
            Platform.runLater(() -> menuList.setItems(FXCollections.observableArrayList(items)));
        }, "menu-loader");
        loader.setDaemon(true);
        loader.start();
    }

    private void updateOrderTotal() {
        if (activeOrder == null) {
            orderTotalLabel.setText("Running total: 0.00 EGP");
        } else {
            orderTotalLabel.setText("Running total: " + DisplayFormat.money(activeOrder.getTotal()) + " EGP");
        }
    }

    private int parseIntOrDefault(String text, int fallback) {
        try {
            return text == null || text.isBlank() ? fallback : Integer.parseInt(text);
        } catch (NumberFormatException ex) {
            return fallback;
        }
    }

    private LocalTime parseReservationTime() {
        try {
            return LocalTime.parse(reservationTimeField.getText().trim());
        } catch (Exception ex) {
            throw new RestaurantException("Enter time as HH:mm, for example 19:30.");
        }
    }

    private int parsePartySize() {
        try {
            return Integer.parseInt(partySizeField.getText().trim());
        } catch (Exception ex) {
            throw new RestaurantException("Enter party size as a whole number.");
        }
    }

    @Override
    public void onOrderStatus(int orderId, String status) {
        for (Order order : customer.getOrders()) {
            if (order.getId() == orderId) {
                try {
                    order.updateStatus(OrderStatus.valueOf(status));
                } catch (IllegalArgumentException ignored) {
                }
                networkLabel.setText("Order " + DisplayFormat.number(orderId) + " status updated to " + status);
                refreshAll();
                return;
            }
        }
    }

    @Override
    public void onMessage(String message) {
        networkLabel.setText(message);
    }
}
