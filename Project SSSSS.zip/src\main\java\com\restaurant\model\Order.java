package com.restaurant.model;

import com.restaurant.enums.OrderStatus;
import com.restaurant.exception.RestaurantException;
import com.restaurant.util.DisplayFormat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Order {
    private final int id;
    private final Customer customer;
    private final RestaurantTable table;
    private final List<OrderItem> items = new ArrayList<>();
    private OrderStatus status = OrderStatus.PLACED;

    public Order(int id, Customer customer, RestaurantTable table) {
        this.id = id;
        this.customer = customer;
        this.table = table;
    }

    public int getId() {
        return id;
    }

    public Customer getCustomer() {
        return customer;
    }

    public RestaurantTable getTable() {
        return table;
    }

    public List<OrderItem> getItems() {
        return Collections.unmodifiableList(items);
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void addItem(MenuItem menuItem, int quantity, String notes) {
        if (quantity <= 0) {
            throw new RestaurantException("Quantity must be positive.");
        }
        for (OrderItem item : items) {
            if (item.getMenuItem() == menuItem) {
                item.setQuantity(item.getQuantity() + quantity);
                item.setNotes(notes);
                return;
            }
        }
        items.add(new OrderItem(menuItem, quantity, notes));
    }

    public void removeItem(MenuItem menuItem) {
        items.removeIf(item -> item.getMenuItem() == menuItem);
    }

    public void changeQuantity(MenuItem menuItem, int quantity) {
        for (OrderItem item : items) {
            if (item.getMenuItem() == menuItem) {
                item.setQuantity(quantity);
                return;
            }
        }
        throw new RestaurantException("Item is not in this order.");
    }

    public double getTotal() {
        double total = 0;
        for (OrderItem item : items) {
            total += item.getLineTotal();
        }
        return total;
    }

    public void updateStatus(OrderStatus newStatus) {
        if (newStatus == null) {
            throw new RestaurantException("Order status is required.");
        }
        if (status == OrderStatus.PAID && newStatus != OrderStatus.PAID) {
            throw new RestaurantException("Paid orders cannot be changed.");
        }
        if (newStatus.ordinal() < status.ordinal()) {
            throw new RestaurantException("Order status cannot move backwards.");
        }
        status = newStatus;
    }

    public void markPaid() {
        status = OrderStatus.PAID;
    }

    @Override
    public String toString() {
        return "Order " + DisplayFormat.number(id) + " - " + status + " - " + customer.getUsername();
    }
}
