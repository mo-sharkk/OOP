package com.restaurant.model;

import com.restaurant.exception.RestaurantException;
import com.restaurant.util.DisplayFormat;

public class MenuItem {
    private int id;
    private String name;
    private double price;
    private String description;
    private MenuCategory category;
    private boolean available;

    public MenuItem(int id, String name, double price, String description, MenuCategory category, boolean available) {
        if (price < 0) {
            throw new RestaurantException("Menu item price cannot be negative.");
        }
        this.id = id;
        this.name = name;
        this.price = price;
        this.description = description;
        this.category = category;
        this.available = available;
        if (category != null) {
            category.addItem(this);
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        if (price < 0) {
            throw new RestaurantException("Menu item price cannot be negative.");
        }
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public MenuCategory getCategory() {
        return category;
    }

    public void setCategory(MenuCategory category) {
        if (this.category != null) {
            this.category.removeItem(this);
        }
        this.category = category;
        if (category != null) {
            category.addItem(this);
        }
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    @Override
    public String toString() {
        return name + " - " + DisplayFormat.money(price) + " EGP";
    }
}
