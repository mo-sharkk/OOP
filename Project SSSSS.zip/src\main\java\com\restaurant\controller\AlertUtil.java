package com.restaurant.controller;

import javafx.scene.control.Alert;

public final class AlertUtil {
    private AlertUtil() {
    }

    public static void info(String message) {
        show(Alert.AlertType.INFORMATION, "Information", message);
    }

    public static void error(String message) {
        show(Alert.AlertType.ERROR, "Error", message);
    }

    private static void show(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
