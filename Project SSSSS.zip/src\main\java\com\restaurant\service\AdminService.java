package com.restaurant.service;

import com.restaurant.database.RestaurantDatabase;
import com.restaurant.enums.TableLocation;
import com.restaurant.exception.RestaurantException;
import com.restaurant.interfaces.Manageable;
import com.restaurant.model.MenuCategory;
import com.restaurant.model.MenuItem;
import com.restaurant.model.RestaurantTable;

import java.util.ArrayList;
import java.util.List;

public class AdminService implements Manageable<RestaurantTable> {
    @Override
    public synchronized void create(RestaurantTable table) {
        if (RestaurantDatabase.findTable(table.getTableNumber()) != null) {
            throw new RestaurantException("Table number already exists.");
        }
        RestaurantDatabase.tables.add(table);
    }

    @Override
    public List<RestaurantTable> readAll() {
        return getTables();
    }

    @Override
    public synchronized void update(RestaurantTable table) {
        if (table == null || RestaurantDatabase.findTable(table.getTableNumber()) == null) {
            throw new RestaurantException("Table does not exist.");
        }
    }

    @Override
    public synchronized void delete(RestaurantTable table) {
        deleteTable(table);
    }

    public synchronized RestaurantTable createTable(int number, int capacity, TableLocation location) {
        RestaurantTable table = new RestaurantTable(number, capacity, location);
        create(table);
        return table;
    }

    public synchronized void deleteTable(RestaurantTable table) {
        if (table != null) {
            RestaurantDatabase.tables.remove(table);
        }
    }

    public synchronized MenuCategory createCategory(String name, String description) {
        MenuCategory category = new MenuCategory(RestaurantDatabase.nextCategoryId(), name, description);
        RestaurantDatabase.menuCategories.add(category);
        return category;
    }

    public synchronized void deleteCategory(MenuCategory category) {
        if (category != null && category.getItems().isEmpty()) {
            RestaurantDatabase.menuCategories.remove(category);
        } else {
            throw new RestaurantException("Delete menu items before deleting the category.");
        }
    }

    public synchronized MenuItem createMenuItem(String name, double price, String description, MenuCategory category, boolean available) {
        MenuItem item = new MenuItem(RestaurantDatabase.nextMenuItemId(), name, price, description, category, available);
        RestaurantDatabase.menuItems.add(item);
        return item;
    }

    public synchronized void deleteMenuItem(MenuItem item) {
        if (item != null) {
            if (item.getCategory() != null) {
                item.getCategory().removeItem(item);
            }
            RestaurantDatabase.menuItems.remove(item);
        }
    }

    public List<RestaurantTable> getTables() {
        return RestaurantDatabase.tableSnapshot();
    }

    public List<MenuCategory> getCategories() {
        synchronized (RestaurantDatabase.class) {
            return new ArrayList<>(RestaurantDatabase.menuCategories);
        }
    }

    public List<MenuItem> getMenuItems() {
        return RestaurantDatabase.menuItemSnapshot();
    }
}
