package com.restaurant;

import com.restaurant.database.RestaurantDatabase;
import com.restaurant.enums.OrderStatus;
import com.restaurant.enums.PaymentMethod;
import com.restaurant.enums.TableLocation;
import com.restaurant.exception.RestaurantException;
import com.restaurant.model.*;
import com.restaurant.network.RestaurantServer;
import com.restaurant.service.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.net.Socket;
import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class RestaurantBackendTest {
    private AuthenticationService auth;
    private ReservationService reservations;
    private OrderService orders;
    private AdminService admin;
    private PaymentService payments;

    @BeforeEach
    void setUp() {
        RestaurantDatabase.resetForTests();
        auth = new AuthenticationService();
        reservations = new ReservationService();
        orders = new OrderService();
        admin = new AdminService();
        payments = new PaymentService();
    }

    @Test
    void validAndInvalidLoginWork() {
        assertTrue(auth.login("customer1", "password123").isCustomer());
        assertEquals("Admin Dashboard", auth.login("admin", "admin123").getStaff().getDashboardTitle());
        assertThrows(RestaurantException.class, () -> auth.login("customer1", "wrong"));
    }

    @Test
    void registrationValidatesDuplicatePasswordAndPhone() {
        Customer created = auth.registerCustomer("new_customer", "abc12345", "abc12345",
                LocalDate.of(2000, 1, 1), "01122223333", "Outdoor");
        assertEquals("new_customer", created.getUsername());
        assertThrows(RestaurantException.class, () -> auth.registerCustomer("customer1", "abc12345", "abc12345",
                LocalDate.of(2000, 1, 1), "01122223333", ""));
        assertThrows(RestaurantException.class, () -> auth.registerCustomer("badphone", "abc12345", "abc12345",
                LocalDate.of(2000, 1, 1), "123", ""));
        assertThrows(RestaurantException.class, () -> auth.registerCustomer("weakpass", "abcdefghi", "abcdefghi",
                LocalDate.of(2000, 1, 1), "01122223333", ""));
    }

    @Test
    void reservationCreationCancellationAndInvalidCases() {
        Customer customer = RestaurantDatabase.findCustomer("customer1");
        RestaurantTable table = RestaurantDatabase.findTable(2);
        LocalDateTime slot = LocalDateTime.now().plusDays(2).withHour(19).withMinute(0).withSecond(0).withNano(0);

        Reservation reservation = reservations.createReservation(customer, table, slot, 4);
        assertTrue(customer.getReservations().contains(reservation));
        assertThrows(RestaurantException.class, () -> reservations.createReservation(customer, table, slot.plusMinutes(30), 4));
        assertThrows(RestaurantException.class, () -> reservations.createReservation(customer, table, slot.plusDays(1), 9));
        assertThrows(RestaurantException.class, () -> reservations.createReservation(customer, table, slot.withHour(8), 4));

        reservations.cancelReservation(reservation);
        assertTrue(reservation.isCancelled());
    }

    @Test
    void orderInvoiceAndPaymentWork() {
        Customer customer = RestaurantDatabase.findCustomer("customer1");
        RestaurantTable table = RestaurantDatabase.findTable(1);
        MenuItem available = RestaurantDatabase.menuItems.get(0);
        MenuItem unavailable = RestaurantDatabase.menuItems.get(RestaurantDatabase.menuItems.size() - 1);

        Order order = orders.createOrder(customer, table);
        orders.addItem(order, available, 2, "No onion");
        assertEquals(170, order.getTotal(), 0.01);
        assertThrows(RestaurantException.class, () -> orders.addItem(order, unavailable, 1, ""));
        assertThrows(RestaurantException.class, () -> orders.addItem(order, available, 0, ""));

        orders.updateStatus(order, OrderStatus.PREPARING);
        assertEquals(OrderStatus.PREPARING, order.getStatus());
        Invoice invoice = orders.checkout(order);
        assertEquals(170, invoice.getSubtotal(), 0.01);
        assertEquals(44.2, invoice.getTax() + invoice.getServiceCharge(), 0.01);
        payments.pay(invoice, PaymentMethod.CARD);
        assertTrue(invoice.isPaid());
        assertEquals(OrderStatus.PAID, order.getStatus());
    }

    @Test
    void adminCrudWorks() {
        RestaurantTable table = admin.createTable(20, 4, TableLocation.VIP);
        assertSame(table, RestaurantDatabase.findTable(20));
        table.setCapacity(6);
        assertEquals(6, RestaurantDatabase.findTable(20).getCapacity());
        admin.deleteTable(table);
        assertNull(RestaurantDatabase.findTable(20));

        MenuCategory category = admin.createCategory("Soups", "Warm starters");
        MenuItem item = admin.createMenuItem("Tomato Soup", 75, "Fresh tomato soup", category, true);
        item.setPrice(80);
        assertEquals(80, item.getPrice(), 0.01);
        admin.deleteMenuItem(item);
        admin.deleteCategory(category);
        assertFalse(RestaurantDatabase.menuCategories.contains(category));
    }

    @Test
    void networkBroadcastsOrderStatusToMultipleClients() throws Exception {
        int port = 6060;
        RestaurantServer server = new RestaurantServer(port);
        Thread serverThread = new Thread(() -> {
            try {
                server.start();
            } catch (IOException ignored) {
            }
        });
        serverThread.setDaemon(true);
        serverThread.start();
        Thread.sleep(250);

        try (Socket client1 = new Socket("localhost", port);
             Socket client2 = new Socket("localhost", port);
             PrintWriter writer = new PrintWriter(new OutputStreamWriter(client1.getOutputStream()), true);
             BufferedReader reader = new BufferedReader(new InputStreamReader(client2.getInputStream()))) {
            client2.setSoTimeout(3000);
            Thread.sleep(250);
            writer.println("ORDER_STATUS|101|PREPARING");
            assertEquals("ORDER_STATUS|101|PREPARING", reader.readLine());
        } finally {
            server.stop();
        }
    }
}
