package com.restaurant.interfaces;

import java.util.List;

public interface Manageable<T> {
    void create(T item);
    List<T> readAll();
    void update(T item);
    void delete(T item);
}
