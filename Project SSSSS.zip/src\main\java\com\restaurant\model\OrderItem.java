package com.restaurant.model;

import com.restaurant.exception.RestaurantException;

public class OrderItem {
    private final MenuItem menuItem;
    private int quantity;
    private String notes;

    public OrderItem(MenuItem menuItem, int quantity, String notes) {
        if (menuItem == null || !menuItem.isAvailable()) {
            throw new RestaurantException("Only available menu items can be ordered.");
        }
        setQuantity(quantity);
        this.menuItem = menuItem;
        this.notes = notes == null ? "" : notes;
    }

    public MenuItem getMenuItem() {
        return menuItem;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        if (quantity <= 0) {
            throw new RestaurantException("Quantity must be positive.");
        }
        this.quantity = quantity;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes == null ? "" : notes;
    }

    public double getLineTotal() {
        return menuItem.getPrice() * quantity;
    }
}
