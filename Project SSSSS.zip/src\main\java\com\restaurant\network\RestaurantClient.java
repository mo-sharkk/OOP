package com.restaurant.network;

import javafx.application.Platform;

import java.io.*;
import java.net.Socket;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class RestaurantClient implements Closeable {
    private final String host;
    private final int port;
    private final List<NetworkMessageListener> listeners = new CopyOnWriteArrayList<>();
    private Socket socket;
    private PrintWriter writer;
    private Thread listenerThread;
    private volatile boolean running;

    public RestaurantClient(String host, int port) {
        this.host = host;
        this.port = port;
    }

    public void connect() {
        try {
            socket = new Socket(host, port);
            writer = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
            running = true;
            listenerThread = new Thread(this::listen, "restaurant-client-listener");
            listenerThread.setDaemon(true);
            listenerThread.start();
        } catch (IOException ex) {
            notifyMessage("Server unavailable. Real-time updates are disabled.");
        }
    }

    public void addListener(NetworkMessageListener listener) {
        listeners.add(listener);
    }

    public void removeListener(NetworkMessageListener listener) {
        listeners.remove(listener);
    }

    public void sendOrderStatus(int orderId, String status) {
        send("ORDER_STATUS|" + orderId + "|" + status);
    }

    public void send(String message) {
        if (writer != null) {
            writer.println(message);
        }
    }

    private void listen() {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
            String line;
            while (running && (line = reader.readLine()) != null) {
                handle(line);
            }
        } catch (IOException ex) {
            if (running) {
                notifyMessage("Connection to server was lost.");
            }
        }
    }

    private void handle(String line) {
        String[] parts = line.split("\\|");
        if (parts.length == 3 && "ORDER_STATUS".equals(parts[0])) {
            try {
                int orderId = Integer.parseInt(parts[1]);
                for (NetworkMessageListener listener : listeners) {
                    Platform.runLater(() -> listener.onOrderStatus(orderId, parts[2]));
                }
            } catch (NumberFormatException ex) {
                notifyMessage("Malformed order status message: " + line);
            }
        } else {
            notifyMessage(line);
        }
    }

    private void notifyMessage(String message) {
        for (NetworkMessageListener listener : listeners) {
            Platform.runLater(() -> listener.onMessage(message));
        }
    }

    @Override
    public void close() {
        running = false;
        try {
            if (socket != null) {
                socket.close();
            }
        } catch (IOException ignored) {
        }
    }
}
