package com.restaurant.model;

import com.restaurant.enums.PaymentMethod;
import com.restaurant.enums.PaymentStatus;
import com.restaurant.interfaces.Payable;
import com.restaurant.util.RestaurantConstants;

public class Invoice implements Payable {
    private final int id;
    private final Order order;
    private PaymentStatus paymentStatus = PaymentStatus.UNPAID;
    private PaymentMethod paymentMethod;

    public Invoice(int id, Order order) {
        this.id = id;
        this.order = order;
    }

    public int getId() {
        return id;
    }

    public Order getOrder() {
        return order;
    }

    public double getSubtotal() {
        return order.getTotal();
    }

    public double getTax() {
        return getSubtotal() * RestaurantConstants.TAX_RATE;
    }

    public double getServiceCharge() {
        return getSubtotal() * RestaurantConstants.SERVICE_RATE;
    }

    public double getFinalTotal() {
        return getSubtotal() + getTax() + getServiceCharge();
    }

    public PaymentStatus getPaymentStatus() {
        return paymentStatus;
    }

    public PaymentMethod getPaymentMethod() {
        return paymentMethod;
    }

    @Override
    public void pay(PaymentMethod method) {
        paymentMethod = method;
        paymentStatus = PaymentStatus.PAID;
        order.markPaid();
        order.getTable().release();
        order.getCustomer().charge(getFinalTotal());
        order.getCustomer().addLoyaltyPoints((int) (getFinalTotal() / 10));
    }

    @Override
    public boolean isPaid() {
        return paymentStatus == PaymentStatus.PAID;
    }
}
