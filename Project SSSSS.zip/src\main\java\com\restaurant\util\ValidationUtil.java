package com.restaurant.util;

import com.restaurant.exception.RestaurantException;

import java.time.LocalDate;
import java.util.regex.Pattern;

public final class ValidationUtil {
    private static final Pattern USERNAME = Pattern.compile("[A-Za-z][A-Za-z0-9_]{2,19}");
    private static final Pattern PHONE = Pattern.compile("\\+?[0-9]{10,15}");

    private ValidationUtil() {
    }

    public static void requireUsername(String username) {
        if (username == null || !USERNAME.matcher(username).matches()) {
            throw new RestaurantException("Username must start with a letter and contain 3-20 letters, digits, or underscores.");
        }
    }

    public static void requirePassword(String password) {
        if (password == null || password.length() < 8 || !password.matches(".*[A-Za-z].*") || !password.matches(".*[0-9].*")) {
            throw new RestaurantException("Password must be at least 8 characters and contain letters and digits.");
        }
    }

    public static void requirePhone(String phone) {
        if (phone == null || !PHONE.matcher(phone).matches()) {
            throw new RestaurantException("Phone number must contain 10-15 digits and may start with +.");
        }
    }

    public static void requireDateOfBirth(LocalDate dateOfBirth) {
        if (dateOfBirth == null || dateOfBirth.isAfter(LocalDate.now().minusYears(10)) || dateOfBirth.isBefore(LocalDate.now().minusYears(120))) {
            throw new RestaurantException("Date of birth is invalid.");
        }
    }
}
