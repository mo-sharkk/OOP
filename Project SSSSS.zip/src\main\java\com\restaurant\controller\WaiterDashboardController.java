package com.restaurant.controller;

import com.restaurant.Main;
import com.restaurant.database.RestaurantDatabase;
import com.restaurant.enums.OrderStatus;
import com.restaurant.exception.RestaurantException;
import com.restaurant.model.Order;
import com.restaurant.model.RestaurantTable;
import com.restaurant.model.Waiter;
import com.restaurant.service.OrderService;
import com.restaurant.util.DisplayFormat;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class WaiterDashboardController {
    @FXML private Label waiterLabel;
    @FXML private ListView<RestaurantTable> assignedTableList;
    @FXML private ListView<Order> activeOrderList;
    @FXML private TextArea orderDetailsArea;
    @FXML private ComboBox<OrderStatus> statusCombo;

    private final OrderService orderService = new OrderService();
    private Waiter waiter;

    @FXML
    private void initialize() {
        waiter = (Waiter) AppSession.getCurrentStaff();
        waiterLabel.setText("Logged in as " + waiter.getUsername());
        statusCombo.setItems(FXCollections.observableArrayList(OrderStatus.values()));
        activeOrderList.getSelectionModel().selectedItemProperty().addListener((obs, old, order) -> showOrder(order));
        refresh();
    }

    @FXML
    private void refresh() {
        assignedTableList.setItems(FXCollections.observableArrayList(waiter.getAssignedTables()));
        List<Order> assignedOrders = new ArrayList<>();
        for (Order order : RestaurantDatabase.orderSnapshot()) {
            if (waiter.getAssignedTables().contains(order.getTable()) && order.getStatus() != OrderStatus.PAID) {
                assignedOrders.add(order);
            }
        }
        activeOrderList.setItems(FXCollections.observableArrayList(assignedOrders));
    }

    @FXML
    private void updateStatus() {
        try {
            Order order = activeOrderList.getSelectionModel().getSelectedItem();
            OrderStatus status = statusCombo.getValue();
            orderService.updateStatus(order, status);
            Main.getClient().sendOrderStatus(order.getId(), status.name());
            AlertUtil.info("Order status updated.");
            refresh();
        } catch (RestaurantException ex) {
            AlertUtil.error(ex.getMessage());
        }
    }

    @FXML
    private void markPreparing() {
        statusCombo.setValue(OrderStatus.PREPARING);
        updateStatus();
    }

    @FXML
    private void markServed() {
        statusCombo.setValue(OrderStatus.SERVED);
        updateStatus();
    }

    @FXML
    private void manageSeating() {
        RestaurantTable table = assignedTableList.getSelectionModel().getSelectedItem();
        if (table != null) {
            AlertUtil.info(table + " status is " + table.getStatus());
        }
    }

    @FXML
    private void logout() throws IOException {
        AppSession.clear();
        Main.showScreen("/fxml/Login.fxml");
    }

    private void showOrder(Order order) {
        if (order == null) {
            orderDetailsArea.clear();
            return;
        }
        statusCombo.setValue(order.getStatus());
        StringBuilder builder = new StringBuilder();
        builder.append("Order ").append(DisplayFormat.number(order.getId())).append("\n");
        builder.append("Customer: ").append(order.getCustomer().getUsername()).append("\n");
        builder.append("Table: ").append(DisplayFormat.number(order.getTable().getTableNumber())).append("\n");
        builder.append("Status: ").append(order.getStatus()).append("\n\nItems:\n");
        for (com.restaurant.model.OrderItem item : order.getItems()) {
            builder.append(DisplayFormat.number(item.getQuantity())).append(" x ").append(item.getMenuItem().getName())
                    .append(" = ").append(DisplayFormat.money(item.getLineTotal())).append("\n");
        }
        builder.append("\nTotal: ").append(DisplayFormat.money(order.getTotal()));
        orderDetailsArea.setText(builder.toString());
    }
}
