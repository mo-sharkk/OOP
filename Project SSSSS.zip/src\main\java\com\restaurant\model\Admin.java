package com.restaurant.model;

import com.restaurant.enums.Role;

import java.time.LocalDate;

public class Admin extends Staff {
    public Admin(String username, String password, LocalDate dateOfBirth, String workingHours) {
        super(username, password, dateOfBirth, Role.ADMIN, workingHours);
    }

    @Override
    public String getDashboardTitle() {
        return "Admin Dashboard";
    }
}
