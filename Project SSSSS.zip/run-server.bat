@echo off
cd /d "%~dp0"
set "JAVA_HOME=C:\Users\moels\OneDrive\Desktop\IntelliJ IDEA 2026.1.4\jbr"
set "MAVEN_OPTS=-Duser.language=en -Duser.country=US"
set "PATH=%JAVA_HOME%\bin;%PATH%"
"C:\Users\moels\OneDrive\Desktop\IntelliJ IDEA 2026.1.4\plugins\maven\lib\maven3\bin\mvn.cmd" exec:java -Dexec.mainClass=com.restaurant.network.RestaurantServer
pause
