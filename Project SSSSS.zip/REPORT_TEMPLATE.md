# Restaurant Table Reservation & Ordering System Report

## 1. Cover Page

Project title, course name, university, faculty, instructor, section, team member names, and submission date.

## 2. Introduction

This project implements a Java desktop restaurant system for reservations, ordering, checkout, staff management, multithreading, and socket networking.

## 3. Problem Description

Restaurants need a simple way to manage table availability, reservations, customer orders, payments, and waiter order status updates.

## 4. Project Objectives

- Build a complete Java OOP backend.
- Build a JavaFX GUI.
- Validate user input.
- Demonstrate OOP concepts.
- Demonstrate multithreading and synchronization.
- Demonstrate Java Socket client/server networking.

## 5. Requirements

Use Java, Maven, JavaFX, FXML, CSS, static `ArrayList` in-memory storage, threads, synchronization, and sockets. No database or external frameworks are used.

## 6. System Analysis

Main actors are Customer, Admin, and Waiter. Customers reserve tables and order food. Admins manage restaurant data. Waiters manage assigned tables and order statuses.

## 7. System Design

The project is separated into model, enum, interface, database, service, controller, network, and resource packages.

## 8. OOP Design

The design uses `Staff` as an abstract superclass, `Payable` as a payment contract, and clear relationships between customers, reservations, tables, orders, and invoices.

## 9. Class Descriptions

Add screenshots or code snippets for `Customer`, `Staff`, `Admin`, `Waiter`, `RestaurantTable`, `Reservation`, `MenuCategory`, `MenuItem`, `Order`, `OrderItem`, `Invoice`, and `RestaurantDatabase`.

## 10. UML Class Diagram

Include `UML_CLASS_DIAGRAM.puml` rendered as an image.

## 11-18. OOP Concepts

Explain inheritance, encapsulation, polymorphism, abstraction, interfaces, association, aggregation, and composition using exact classes from the project.

## 19-21. JavaFX GUI, FXML, CSS

Describe the login, customer, admin, and waiter screens. Include screenshots of each screen.

## 22-24. Multithreading and Synchronization

Explain background menu loading, scheduled table refresh, socket listener thread, server executor, and synchronized service/database operations.

## 25-26. Client-Server Networking

Explain `RestaurantServer`, `RestaurantClient`, `ServerSocket`, `Socket`, and the message format `ORDER_STATUS|orderId|status`.

## 27. Validation

Describe username, password, phone, date of birth, reservation, order, and payment validation.

## 28. Testing

Summarize automated JUnit tests and manual GUI test cases from `TEST_CASES.md`.

## 29. Sample Outputs

Add screenshots of successful login, reservation confirmation, order placement, checkout, admin CRUD, waiter status update, and server logs.

## 30. Limitations

In-memory data resets on restart. Passwords are plain strings for educational scope.

## 31. Future Improvements

Add persistent storage, stronger authentication, reports, table floor map, and optional customer-waiter chat.

## 32. Conclusion

The project demonstrates a complete CSE241 Java OOP desktop application with GUI, validation, multithreading, synchronization, and sockets.

## 33. Team Member Contributions

- `[Name]`: `[Contribution]`
- `[Name]`: `[Contribution]`
