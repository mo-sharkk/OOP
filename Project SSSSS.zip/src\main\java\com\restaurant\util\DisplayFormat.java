package com.restaurant.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public final class DisplayFormat {
    public static final Locale LOCALE = Locale.US;

    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("yyyy-MM-dd", LOCALE);
    private static final DateTimeFormatter DATE_TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm", LOCALE);

    private DisplayFormat() {
    }

    public static String money(double amount) {
        return String.format(LOCALE, "%.2f", amount);
    }

    public static String number(int value) {
        return String.format(LOCALE, "%d", value);
    }

    public static String decimal(double value) {
        return String.format(LOCALE, "%.2f", value);
    }

    public static String date(LocalDate date) {
        return date == null ? "" : DATE.format(date);
    }

    public static String dateTime(LocalDateTime dateTime) {
        return dateTime == null ? "" : DATE_TIME.format(dateTime);
    }
}
