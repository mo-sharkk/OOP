# VIVA Guide

## 1. Architecture

The project uses layers. Model classes in `com.restaurant.model` store restaurant objects. `RestaurantDatabase` stores static `ArrayList` data. Service classes contain business rules. JavaFX controllers connect screens to services. Network classes handle sockets.

Example:

```java
Order order = orderService.createOrder(customer, table);
```

This keeps GUI code separate from order logic.

## 2. Important Classes

`Customer` stores username, password, date of birth, balance, phone, loyalty points, dietary preferences, reservations, and orders. Fields are private to demonstrate encapsulation.

`Staff` is an abstract class for common staff data. `Admin` and `Waiter` extend it. This demonstrates inheritance.

`Admin` represents staff who can manage restaurant data through `AdminService`.

`Waiter` stores assigned tables and updates active order statuses.

`RestaurantTable` stores table number, capacity, location, status, active reservation, and active order. Methods such as `reserve`, `occupy`, and `release` prevent invalid table states.

`Reservation` links a `Customer`, a `RestaurantTable`, a date/time, and party size. Its `overlaps` method helps prevent double booking.

`MenuCategory` groups menu items. This is aggregation because items can be moved between categories.

`MenuItem` stores item name, price, description, category, and availability.

`Order` links a customer, table, order items, and status. It validates status flow and calculates total.

`OrderItem` contains a menu item, quantity, and notes. It is composition because it belongs to one order.

`Invoice` calculates subtotal, tax, service charge, final total, and payment status. It implements `Payable`.

`RestaurantDatabase` contains the in-memory static `ArrayList` fields and sample data.

## 3. OOP Concepts

Encapsulation means hiding data inside classes. Example: `Customer` fields are private and accessed through getters and controlled methods.

Information hiding means external code cannot directly change sensitive state. Example: `Order.getItems()` returns an unmodifiable list.

Abstraction means showing essential behavior without unnecessary details. Example: `Staff` defines common staff fields and `getDashboardTitle()`.

Inheritance is used in `Admin extends Staff` and `Waiter extends Staff`.

Polymorphism appears when login returns a `Staff` reference, but the actual object can be `Admin` or `Waiter`.

Association appears in `Reservation`, which links a customer and table.

Aggregation appears in `MenuCategory`, which groups `MenuItem` objects.

Composition appears in `Order`, which owns its `OrderItem` list.

Interface appears in `Payable`, implemented by `Invoice`, and `Manageable<RestaurantTable>`, implemented by `AdminService` for table management.

Abstract class appears in `Staff`, because staff should not be instantiated directly.

Method overriding appears in `Admin.getDashboardTitle()` and `Waiter.getDashboardTitle()`.

Method overloading appears in constructors and service usage patterns where classes provide focused methods with different parameter groups.

Enums are used for `Role`, `TableStatus`, `TableLocation`, `OrderStatus`, `PaymentMethod`, and `PaymentStatus`.

Exception handling uses `RestaurantException` for validation errors, caught by JavaFX controllers and shown in alerts.

Collections are static `ArrayList` fields in `RestaurantDatabase`.

## 4. JavaFX

`Main` extends `Application`. The `start(Stage stage)` method initializes data, creates the socket client, and loads `Login.fxml`.

`Stage` is the main window. `Scene` contains one screen layout. `Main.showScreen()` switches scenes by loading FXML.

FXML files define the visual layout: `Login.fxml`, `CustomerDashboard.fxml`, `AdminDashboard.fxml`, and `WaiterDashboard.fxml`.

Controllers handle events. Example: `LoginController.login()` checks credentials and opens the correct dashboard.

CSS is in `restaurant.css` and styles headers, panels, buttons, fields, and lists.

Event handling is done with `onAction="#methodName"` in FXML.

`ListView` is used for tables, menu items, reservations, customers, and orders. Alerts show success and error feedback.

## 5. Multithreading

`Thread` is used in `CustomerDashboardController.loadMenuInBackground()` so menu loading does not block the GUI.

`Runnable` is used by thread bodies and scheduled refresh tasks.

`ExecutorService` is used in `RestaurantServer` to handle multiple clients concurrently.

Background tasks keep the JavaFX Application Thread responsive.

JavaFX UI must only be changed on the JavaFX Application Thread. The client listener uses:

```java
Platform.runLater(() -> listener.onOrderStatus(orderId, status));
```

A race condition can happen if two threads reserve the same table at the same time. The service methods use `synchronized` and synchronized blocks around shared `RestaurantDatabase` operations.

Thread safety is important because GUI refreshes, socket listeners, and server client handlers can access shared state.

## 6. Networking

`RestaurantServer` uses `ServerSocket` to accept clients on port `5050`.

Each client uses a `Socket`. The server creates a `ClientHandler` for every connection and runs handlers using an `ExecutorService`.

`RestaurantClient` connects from the JavaFX app, listens in a background thread, and sends messages using `PrintWriter`.

The message protocol is:

```text
ORDER_STATUS|orderId|status
```

Example:

```text
ORDER_STATUS|101|PREPARING
```

When the waiter updates an order, `WaiterDashboardController` updates the local order and calls `Main.getClient().sendOrderStatus(...)`. The server validates and broadcasts the message. Customer clients receive it and update the GUI using `Platform.runLater()`.

Malformed messages are rejected by the server with `ERROR|Malformed message`.

## 7. Demo Flow

1. Start `RestaurantServer`.
2. Run `mvn javafx:run`.
3. Login as `customer1 / password123`.
4. Select a table, create a reservation, start an order, add menu items, and view checkout.
5. Open another client and login as `waiter / waiter123`.
6. Waiter selects the active order and changes status to `PREPARING` or `SERVED`.
7. Customer screen receives the live order status message.
8. Customer pays the invoice using cash, card, or online.
