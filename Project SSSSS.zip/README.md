# Restaurant Table Reservation & Ordering System

## Project Description

Java desktop application for restaurant table reservations, menu ordering, checkout, staff administration, waiter order handling, and live order-status updates.

## Features

- Customer registration and login.
- Admin and waiter login.
- Customer dashboard with balance, loyalty points, reservations, and orders.
- Table browsing with location and capacity filters.
- Reservation creation, validation, history, and cancellation.
- Menu browsing and item ordering.
- Invoice checkout with tax, service charge, and payment methods.
- Admin CRUD for tables, menu categories, and menu items.
- Waiter assigned-table view and order status updates.
- Background menu loading and periodic table availability refresh.
- Java Socket server/client order status feed.

## Technologies

Java 17, Maven, JavaFX, FXML, CSS, JUnit 5, `ArrayList`, enums, interfaces, abstract classes, `Thread`, `Runnable`, `ExecutorService`, `ServerSocket`, and `Socket`.

## Requirements

- JDK 17 or newer.
- Maven 3.8 or newer.

## Build Instructions

```bash
mvn clean package
```

## Run Instructions

Start the server in one terminal:

```bash
mvn exec:java -Dexec.mainClass=com.restaurant.network.RestaurantServer
```

Or run it directly from the compiled classes/IDE using `com.restaurant.network.RestaurantServer`.

Start the JavaFX client:

```bash
mvn javafx:run
```

The JavaFX application still opens if the server is unavailable, but real-time socket updates are disabled until the server is running.

## Sample Credentials

- Customer: `customer1 / password123`
- Customer: `customer2 / password123`
- Admin: `admin / admin123`
- Waiter: `waiter / waiter123`
- Waiter: `waiter2 / waiter123`

## Project Structure

- `src/main/java/com/restaurant/model`: OOP model classes.
- `src/main/java/com/restaurant/enums`: role, table, order, and payment enums.
- `src/main/java/com/restaurant/interfaces`: `Payable` and `Manageable`.
- `src/main/java/com/restaurant/database`: static in-memory `ArrayList` database.
- `src/main/java/com/restaurant/service`: business logic.
- `src/main/java/com/restaurant/controller`: JavaFX controllers.
- `src/main/java/com/restaurant/network`: socket client and server.
- `src/main/resources/fxml`: FXML screens.
- `src/main/resources/css`: stylesheet.
- `src/test/java`: automated tests.
- `UML_CLASS_DIAGRAM.puml`: PlantUML class diagram.

## OOP Concepts

- Encapsulation: private fields and controlled methods in model classes.
- Inheritance: `Admin` and `Waiter` extend abstract `Staff`.
- Polymorphism: staff login returns a `Staff` reference whose runtime type decides the dashboard.
- Abstraction: `Staff` defines common staff data and dashboard behavior.
- Interface: `Invoice` implements `Payable`.
- Association: `Reservation` links `Customer` and `RestaurantTable`.
- Aggregation: `MenuCategory` groups menu items.
- Composition: `Order` owns `OrderItem` objects.
- Collections: `RestaurantDatabase` uses static `ArrayList` fields.

## Testing

Run:

```bash
mvn test
```

Tests cover authentication, registration validation, reservation validation, double booking, cancellation, admin CRUD, order validation, invoice calculation, payment, and socket broadcast.

## Known Limitations

This is an educational in-memory implementation. Data is reset when the application restarts, and passwords are stored as plain strings for CSE241 simplicity. Production systems should use persistent storage and secure password hashing.
