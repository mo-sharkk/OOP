package com.restaurant.util;

import java.time.LocalTime;

public final class RestaurantConstants {
    public static final LocalTime OPENING_TIME = LocalTime.of(10, 0);
    public static final LocalTime CLOSING_TIME = LocalTime.of(23, 0);
    public static final int RESERVATION_LENGTH_MINUTES = 90;
    public static final double TAX_RATE = 0.14;
    public static final double SERVICE_RATE = 0.12;
    public static final int NETWORK_PORT = 5050;
    public static final int TABLE_REFRESH_SECONDS = 5;

    private RestaurantConstants() {
    }
}
