# How To Run

The project is saved here:

```text
C:\Users\moels\OneDrive\Documents\ChatGPT\Agdad haga
```

## Easy Method

1. Double-click `run-server.bat`.
2. Leave the server window open.
3. Double-click `run-app.bat`.

## Login Accounts

- Customer: `customer1 / password123`
- Admin: `admin / admin123`
- Waiter: `waiter / waiter123`

## Manual Commands

If you prefer PowerShell:

```powershell
cd "C:\Users\moels\OneDrive\Documents\ChatGPT\Agdad haga"
$env:JAVA_HOME="C:\Users\moels\OneDrive\Desktop\IntelliJ IDEA 2026.1.4\jbr"
$env:PATH="$env:JAVA_HOME\bin;$env:PATH"
& "C:\Users\moels\OneDrive\Desktop\IntelliJ IDEA 2026.1.4\plugins\maven\lib\maven3\bin\mvn.cmd" exec:java -Dexec.mainClass=com.restaurant.network.RestaurantServer
```

Then open another PowerShell:

```powershell
cd "C:\Users\moels\OneDrive\Documents\ChatGPT\Agdad haga"
$env:JAVA_HOME="C:\Users\moels\OneDrive\Desktop\IntelliJ IDEA 2026.1.4\jbr"
$env:PATH="$env:JAVA_HOME\bin;$env:PATH"
& "C:\Users\moels\OneDrive\Desktop\IntelliJ IDEA 2026.1.4\plugins\maven\lib\maven3\bin\mvn.cmd" javafx:run
```
