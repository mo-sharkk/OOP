package com.restaurant;

import com.restaurant.database.RestaurantDatabase;
import com.restaurant.network.RestaurantClient;
import com.restaurant.util.RestaurantConstants;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Locale;

public class Main extends Application {
    private static Stage primaryStage;
    private static RestaurantClient client;

    @Override
    public void start(Stage stage) throws IOException {
        RestaurantDatabase.initializeSampleData();
        primaryStage = stage;
        primaryStage.setTitle("Restaurant Reservation & Ordering System");
        client = new RestaurantClient("localhost", RestaurantConstants.NETWORK_PORT);
        client.connect();
        showScreen("/fxml/Login.fxml");
        primaryStage.setOnCloseRequest(event -> shutdown());
        primaryStage.show();
    }

    public static void showScreen(String fxmlPath) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource(fxmlPath));
        Parent root = loader.load();
        Scene scene = new Scene(root, 1050, 720);
        scene.getStylesheets().add(Main.class.getResource("/css/restaurant.css").toExternalForm());
        primaryStage.setScene(scene);
    }

    public static RestaurantClient getClient() {
        return client;
    }

    public static void shutdown() {
        if (client != null) {
            client.close();
        }
        Platform.exit();
    }

    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        Locale.setDefault(Locale.Category.FORMAT, Locale.US);
        launch(args);
    }
}
