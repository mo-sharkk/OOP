package com.restaurant.service;

import com.restaurant.enums.PaymentMethod;
import com.restaurant.exception.RestaurantException;
import com.restaurant.model.Invoice;

public class PaymentService {
    public synchronized void pay(Invoice invoice, PaymentMethod method) {
        if (invoice == null || method == null) {
            throw new RestaurantException("Invoice and payment method are required.");
        }
        if (invoice.isPaid()) {
            throw new RestaurantException("Invoice is already paid.");
        }
        invoice.pay(method);
    }
}
