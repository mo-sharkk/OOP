package com.restaurant.model;

import com.restaurant.enums.TableLocation;
import com.restaurant.enums.TableStatus;
import com.restaurant.exception.RestaurantException;
import com.restaurant.util.DisplayFormat;

public class RestaurantTable {
    private int tableNumber;
    private int capacity;
    private TableLocation location;
    private TableStatus status;
    private Reservation activeReservation;
    private Order activeOrder;

    public RestaurantTable(int tableNumber, int capacity, TableLocation location) {
        if (capacity <= 0) {
            throw new RestaurantException("Table capacity must be positive.");
        }
        this.tableNumber = tableNumber;
        this.capacity = capacity;
        this.location = location;
        this.status = TableStatus.AVAILABLE;
    }

    public int getTableNumber() {
        return tableNumber;
    }

    public void setTableNumber(int tableNumber) {
        this.tableNumber = tableNumber;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        if (capacity <= 0) {
            throw new RestaurantException("Table capacity must be positive.");
        }
        this.capacity = capacity;
    }

    public TableLocation getLocation() {
        return location;
    }

    public void setLocation(TableLocation location) {
        this.location = location;
    }

    public TableStatus getStatus() {
        return status;
    }

    public Reservation getActiveReservation() {
        return activeReservation;
    }

    public Order getActiveOrder() {
        return activeOrder;
    }

    public void reserve(Reservation reservation) {
        if (status == TableStatus.OCCUPIED) {
            throw new RestaurantException("Occupied table cannot be reserved.");
        }
        activeReservation = reservation;
        status = TableStatus.RESERVED;
    }

    public void occupy(Order order) {
        if (status == TableStatus.OCCUPIED && activeOrder != order) {
            throw new RestaurantException("Table is already occupied.");
        }
        activeOrder = order;
        status = TableStatus.OCCUPIED;
    }

    public void release() {
        activeReservation = null;
        activeOrder = null;
        status = TableStatus.AVAILABLE;
    }

    @Override
    public String toString() {
        return "Table " + DisplayFormat.number(tableNumber) + " (" + DisplayFormat.number(capacity) + ", " + location + ")";
    }
}
