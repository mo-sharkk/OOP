package com.restaurant.enums;

public enum TableLocation {
    INDOOR,
    OUTDOOR,
    VIP
}
