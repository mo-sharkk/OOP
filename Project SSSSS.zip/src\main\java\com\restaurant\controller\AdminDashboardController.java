package com.restaurant.controller;

import com.restaurant.Main;
import com.restaurant.database.RestaurantDatabase;
import com.restaurant.enums.TableLocation;
import com.restaurant.exception.RestaurantException;
import com.restaurant.model.Customer;
import com.restaurant.model.MenuCategory;
import com.restaurant.model.MenuItem;
import com.restaurant.model.RestaurantTable;
import com.restaurant.service.AdminService;
import com.restaurant.util.DisplayFormat;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.IOException;

public class AdminDashboardController {
    @FXML private ListView<Customer> customerList;
    @FXML private Label customerDetailsLabel;
    @FXML private ListView<RestaurantTable> tableList;
    @FXML private TextField tableNumberField;
    @FXML private TextField tableCapacityField;
    @FXML private ComboBox<TableLocation> tableLocationCombo;
    @FXML private ListView<MenuCategory> categoryList;
    @FXML private TextField categoryNameField;
    @FXML private TextField categoryDescriptionField;
    @FXML private ListView<MenuItem> menuItemList;
    @FXML private TextField itemNameField;
    @FXML private TextField itemPriceField;
    @FXML private TextField itemDescriptionField;
    @FXML private ComboBox<MenuCategory> itemCategoryCombo;
    @FXML private CheckBox itemAvailableCheck;

    private final AdminService adminService = new AdminService();

    @FXML
    private void initialize() {
        tableLocationCombo.setItems(FXCollections.observableArrayList(TableLocation.values()));
        tableLocationCombo.getSelectionModel().select(TableLocation.INDOOR);
        customerList.getSelectionModel().selectedItemProperty().addListener((obs, old, selected) -> showCustomer(selected));
        tableList.getSelectionModel().selectedItemProperty().addListener((obs, old, selected) -> fillTable(selected));
        categoryList.getSelectionModel().selectedItemProperty().addListener((obs, old, selected) -> fillCategory(selected));
        menuItemList.getSelectionModel().selectedItemProperty().addListener((obs, old, selected) -> fillMenuItem(selected));
        refresh();
    }

    @FXML
    private void refresh() {
        customerList.setItems(FXCollections.observableArrayList(RestaurantDatabase.customers));
        tableList.setItems(FXCollections.observableArrayList(adminService.getTables()));
        categoryList.setItems(FXCollections.observableArrayList(adminService.getCategories()));
        itemCategoryCombo.setItems(FXCollections.observableArrayList(adminService.getCategories()));
        menuItemList.setItems(FXCollections.observableArrayList(adminService.getMenuItems()));
    }

    @FXML
    private void saveTable() {
        try {
            RestaurantTable selected = tableList.getSelectionModel().getSelectedItem();
            if (selected == null) {
                adminService.createTable(Integer.parseInt(tableNumberField.getText()), Integer.parseInt(tableCapacityField.getText()), tableLocationCombo.getValue());
            } else {
                selected.setTableNumber(Integer.parseInt(tableNumberField.getText()));
                selected.setCapacity(Integer.parseInt(tableCapacityField.getText()));
                selected.setLocation(tableLocationCombo.getValue());
            }
            refresh();
        } catch (Exception ex) {
            AlertUtil.error(ex.getMessage());
        }
    }

    @FXML
    private void deleteTable() {
        adminService.deleteTable(tableList.getSelectionModel().getSelectedItem());
        refresh();
    }

    @FXML
    private void saveCategory() {
        MenuCategory selected = categoryList.getSelectionModel().getSelectedItem();
        if (selected == null) {
            adminService.createCategory(categoryNameField.getText(), categoryDescriptionField.getText());
        } else {
            selected.setName(categoryNameField.getText());
            selected.setDescription(categoryDescriptionField.getText());
        }
        refresh();
    }

    @FXML
    private void deleteCategory() {
        try {
            adminService.deleteCategory(categoryList.getSelectionModel().getSelectedItem());
            refresh();
        } catch (RestaurantException ex) {
            AlertUtil.error(ex.getMessage());
        }
    }

    @FXML
    private void saveMenuItem() {
        try {
            MenuItem selected = menuItemList.getSelectionModel().getSelectedItem();
            if (selected == null) {
                adminService.createMenuItem(itemNameField.getText(), Double.parseDouble(itemPriceField.getText()),
                        itemDescriptionField.getText(), itemCategoryCombo.getValue(), itemAvailableCheck.isSelected());
            } else {
                selected.setName(itemNameField.getText());
                selected.setPrice(Double.parseDouble(itemPriceField.getText()));
                selected.setDescription(itemDescriptionField.getText());
                selected.setCategory(itemCategoryCombo.getValue());
                selected.setAvailable(itemAvailableCheck.isSelected());
            }
            refresh();
        } catch (Exception ex) {
            AlertUtil.error(ex.getMessage());
        }
    }

    @FXML
    private void deleteMenuItem() {
        adminService.deleteMenuItem(menuItemList.getSelectionModel().getSelectedItem());
        refresh();
    }

    @FXML
    private void clearSelection() {
        tableList.getSelectionModel().clearSelection();
        categoryList.getSelectionModel().clearSelection();
        menuItemList.getSelectionModel().clearSelection();
    }

    @FXML
    private void logout() throws IOException {
        AppSession.clear();
        Main.showScreen("/fxml/Login.fxml");
    }

    private void showCustomer(Customer customer) {
        if (customer == null) {
            customerDetailsLabel.setText("");
        } else {
            customerDetailsLabel.setText("Phone: " + customer.getPhoneNumber()
                    + "\nDOB: " + DisplayFormat.date(customer.getDateOfBirth())
                    + "\nBalance: " + DisplayFormat.money(customer.getBalance()) + " EGP"
                    + "\nLoyalty: " + DisplayFormat.number(customer.getLoyaltyPoints())
                    + "\nPreferences: " + customer.getDietaryPreferences());
        }
    }

    private void fillTable(RestaurantTable table) {
        if (table != null) {
            tableNumberField.setText(String.valueOf(table.getTableNumber()));
            tableCapacityField.setText(String.valueOf(table.getCapacity()));
            tableLocationCombo.setValue(table.getLocation());
        }
    }

    private void fillCategory(MenuCategory category) {
        if (category != null) {
            categoryNameField.setText(category.getName());
            categoryDescriptionField.setText(category.getDescription());
        }
    }

    private void fillMenuItem(MenuItem item) {
        if (item != null) {
            itemNameField.setText(item.getName());
            itemPriceField.setText(DisplayFormat.decimal(item.getPrice()));
            itemDescriptionField.setText(item.getDescription());
            itemCategoryCombo.setValue(item.getCategory());
            itemAvailableCheck.setSelected(item.isAvailable());
        }
    }
}
