package com.restaurant.network;

public interface NetworkMessageListener {
    void onOrderStatus(int orderId, String status);
    void onMessage(String message);
}
