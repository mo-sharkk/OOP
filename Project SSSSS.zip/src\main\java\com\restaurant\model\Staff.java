package com.restaurant.model;

import com.restaurant.enums.Role;

import java.time.LocalDate;

public abstract class Staff {
    private final String username;
    private String password;
    private LocalDate dateOfBirth;
    private final Role role;
    private String workingHours;

    protected Staff(String username, String password, LocalDate dateOfBirth, Role role, String workingHours) {
        this.username = username;
        this.password = password;
        this.dateOfBirth = dateOfBirth;
        this.role = role;
        this.workingHours = workingHours;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public Role getRole() {
        return role;
    }

    public String getWorkingHours() {
        return workingHours;
    }

    public void setWorkingHours(String workingHours) {
        this.workingHours = workingHours;
    }

    public abstract String getDashboardTitle();
}
