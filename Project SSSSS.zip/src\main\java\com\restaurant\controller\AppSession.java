package com.restaurant.controller;

import com.restaurant.model.Customer;
import com.restaurant.model.Staff;

public final class AppSession {
    private static Customer currentCustomer;
    private static Staff currentStaff;

    private AppSession() {
    }

    public static Customer getCurrentCustomer() {
        return currentCustomer;
    }

    public static void setCurrentCustomer(Customer currentCustomer) {
        AppSession.currentCustomer = currentCustomer;
        AppSession.currentStaff = null;
    }

    public static Staff getCurrentStaff() {
        return currentStaff;
    }

    public static void setCurrentStaff(Staff currentStaff) {
        AppSession.currentStaff = currentStaff;
        AppSession.currentCustomer = null;
    }

    public static void clear() {
        currentCustomer = null;
        currentStaff = null;
    }
}
