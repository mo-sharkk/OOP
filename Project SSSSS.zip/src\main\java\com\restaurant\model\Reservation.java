package com.restaurant.model;

import com.restaurant.util.DisplayFormat;

import java.time.LocalDateTime;

public class Reservation {
    private final int id;
    private final Customer customer;
    private final RestaurantTable table;
    private final LocalDateTime dateTime;
    private final int partySize;
    private boolean cancelled;

    public Reservation(int id, Customer customer, RestaurantTable table, LocalDateTime dateTime, int partySize) {
        this.id = id;
        this.customer = customer;
        this.table = table;
        this.dateTime = dateTime;
        this.partySize = partySize;
    }

    public int getId() {
        return id;
    }

    public Customer getCustomer() {
        return customer;
    }

    public RestaurantTable getTable() {
        return table;
    }

    public LocalDateTime getDateTime() {
        return dateTime;
    }

    public int getPartySize() {
        return partySize;
    }

    public boolean isCancelled() {
        return cancelled;
    }

    public void cancel() {
        cancelled = true;
        if (table.getActiveReservation() == this && table.getActiveOrder() == null) {
            table.release();
        }
    }

    public boolean overlaps(LocalDateTime otherStart, int lengthMinutes) {
        LocalDateTime end = dateTime.plusMinutes(lengthMinutes);
        LocalDateTime otherEnd = otherStart.plusMinutes(lengthMinutes);
        return dateTime.isBefore(otherEnd) && otherStart.isBefore(end);
    }

    @Override
    public String toString() {
        return "Reservation " + DisplayFormat.number(id) + " - " + customer.getUsername()
                + " at " + DisplayFormat.dateTime(dateTime);
    }
}
