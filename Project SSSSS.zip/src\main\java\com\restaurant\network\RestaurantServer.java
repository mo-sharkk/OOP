package com.restaurant.network;

import com.restaurant.util.RestaurantConstants;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RestaurantServer {
    private final int port;
    private final Set<ClientHandler> clients = ConcurrentHashMap.newKeySet();
    private final ExecutorService executor = Executors.newCachedThreadPool();
    private volatile boolean running;
    private ServerSocket serverSocket;

    public RestaurantServer(int port) {
        this.port = port;
    }

    public void start() throws IOException {
        serverSocket = new ServerSocket(port);
        running = true;
        System.out.println("Restaurant server started on port " + port);
        while (running) {
            Socket socket = serverSocket.accept();
            ClientHandler handler = new ClientHandler(socket);
            clients.add(handler);
            executor.submit(handler);
            System.out.println("Client connected: " + socket.getRemoteSocketAddress());
        }
    }

    public void stop() {
        running = false;
        for (ClientHandler client : clients) {
            client.close();
        }
        executor.shutdownNow();
        try {
            if (serverSocket != null) {
                serverSocket.close();
            }
        } catch (IOException ignored) {
        }
    }

    private void broadcast(String message) {
        for (ClientHandler client : clients) {
            client.send(message);
        }
    }

    private class ClientHandler implements Runnable, Closeable {
        private final Socket socket;
        private PrintWriter writer;

        ClientHandler(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
                writer = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
                String line;
                while ((line = reader.readLine()) != null) {
                    if (isValidOrderStatus(line)) {
                        System.out.println("Order status update: " + line);
                        broadcast(line);
                    } else {
                        send("ERROR|Malformed message");
                    }
                }
            } catch (IOException ex) {
                System.out.println("Client disconnected: " + socket.getRemoteSocketAddress());
            } finally {
                clients.remove(this);
                close();
            }
        }

        private boolean isValidOrderStatus(String message) {
            String[] parts = message.split("\\|");
            if (parts.length != 3 || !"ORDER_STATUS".equals(parts[0])) {
                return false;
            }
            try {
                Integer.parseInt(parts[1]);
                Enum.valueOf(com.restaurant.enums.OrderStatus.class, parts[2]);
                return true;
            } catch (IllegalArgumentException ex) {
                return false;
            }
        }

        void send(String message) {
            if (writer != null) {
                writer.println(message);
            }
        }

        @Override
        public void close() {
            try {
                socket.close();
            } catch (IOException ignored) {
            }
        }
    }

    public static void main(String[] args) throws IOException {
        int port = args.length > 0 ? Integer.parseInt(args[0]) : RestaurantConstants.NETWORK_PORT;
        new RestaurantServer(port).start();
    }
}
