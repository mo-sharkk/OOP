package com.restaurant.interfaces;

import com.restaurant.enums.PaymentMethod;

public interface Payable {
    void pay(PaymentMethod method);
    boolean isPaid();
}
